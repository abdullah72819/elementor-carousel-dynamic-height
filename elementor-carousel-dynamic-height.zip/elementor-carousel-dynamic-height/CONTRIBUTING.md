# Contributing

Thanks for helping improve this snippet!

## Reporting issues
Open an issue with:
- Elementor and WordPress versions
- A description of what happens vs. what you expected
- A screenshot, if it's a visual problem

## Suggesting changes
1. Fork the repo
2. Create a branch: `git checkout -b fix/short-description`
3. Make your change in the `src/` files
4. Test it on a page with the Elementor Nested Carousel (`.crs-wdg`)
5. Open a pull request describing what you changed and why

## Guidelines
- Keep it minimal. Avoid extra dependencies or over-engineering.
- Don't override Elementor's arrow styling or positioning.
- Update `CHANGELOG.md` for any user-facing change.
