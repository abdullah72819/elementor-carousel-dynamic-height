# Changelog

## [1.0.0] - 2026-10-13
### Added
- JavaScript that sets the carousel height to the active slide's height.
- CSS so slides size to their content, with a smooth height transition.
- `EXTRA` setting to reserve space for the navigation arrows.

### Notes
- Elementor arrow styling and position are left untouched.
