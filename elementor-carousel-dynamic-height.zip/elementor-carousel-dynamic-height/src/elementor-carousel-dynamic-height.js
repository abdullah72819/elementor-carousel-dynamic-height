document.addEventListener('DOMContentLoaded', function () {
    const widget = document.querySelector('.crs-wdg');
    if (!widget) return;

    const swiperEl = widget.querySelector('.swiper');
    if (!swiperEl) return;

    const EXTRA = 70; // extra space (px) under the slide for the arrows

    const initHeight = () => {
        const swiper = swiperEl.swiper;
        if (!swiper) return setTimeout(initHeight, 150);

        const getSlideHeight = (index) => {
            const slide = swiper.slides[index];
            if (!slide) return 0;
            const inner = slide.querySelector('.e-con-inner') || slide;
            return inner.offsetHeight;
        };

        const setHeight = (index) => {
            const h = getSlideHeight(index);
            if (h) swiperEl.style.height = (h + EXTRA) + 'px';
        };

        const resizeToActive = () => setHeight(swiper.activeIndex);

        swiper.on('beforeTransitionStart', () => {
            const dir = swiper.swipeDirection === 'next' ? 1 : -1;
            setHeight(swiper.activeIndex + dir);
        });

        swiper.on('slideChangeTransitionEnd', resizeToActive);
        swiper.on('resize', resizeToActive);
        window.addEventListener('resize', resizeToActive);
        window.addEventListener('load', resizeToActive);

        setTimeout(resizeToActive, 300);
    };

    initHeight();
});
